#ifndef _PROBAORIENTATION_INTERFACE_H_
#define _PROBAORIENTATION_INTERFACE_H_
double* getOrientTplLVDegPropag(int, int*, double*, int, int, int, int);
#endif
