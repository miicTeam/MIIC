#include "structure.h"

void orientation(Environment, string, bool);
