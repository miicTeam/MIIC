#ifndef _ORIENTATION_PROBABILITY_H_
#define _ORIENTATION_PROBABILITY_H_
#include "structure.h"

void orientationProbability(Environment, string, bool);

#endif
