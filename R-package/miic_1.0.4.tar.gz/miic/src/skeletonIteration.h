#ifndef _SKELETONITERATION_H_
#define _SKELETONITERATION_H_
#include "structure.h"

bool skeletonIteration(Environment&);
bool SearchForNewContributingNodeAndItsRank(Environment&, const int, const int);


#endif
